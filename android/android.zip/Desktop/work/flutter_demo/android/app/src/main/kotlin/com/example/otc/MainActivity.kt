package com.example.otc

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

import io.flutter.app.FlutterActivity
import io.flutter.plugins.GeneratedPluginRegistrant
import kotlinx.android.synthetic.main.native_page.*
import java.lang.ref.WeakReference

class MainActivity : AppCompatActivity() {

    companion object {
        var sRef: WeakReference<MainActivity>? = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sRef = WeakReference(this)
        setContentView(R.layout.flutter_fragment_page)

        PageRouter.openPageByUrl(this, PageRouter.FLUTTER_PAGE_URL)
        finish()

//        setContentView(R.layout.native_page)

     /*   open_native.setOnClickListener {
            PageRouter.openPageByUrl(this, PageRouter.NATIVE_PAGE_URL)
        }
        open_flutter.setOnClickListener {
            PageRouter.openPageByUrl(this, PageRouter.FLUTTER_PAGE_URL)
        }
        open_flutter_fragment.setOnClickListener {
            PageRouter.openPageByUrl(this, PageRouter.FLUTTER_FRAGMENT_PAGE_URL)
        }*/
    }

    override fun onDestroy() {
        super.onDestroy()
        sRef?.clear()
        sRef = null
    }
}
